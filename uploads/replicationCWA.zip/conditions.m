function F = conditions( x,b,k,tau,sigma )
% Christian Decker, April 2023

F = zeros(1,tau+sigma+1);
x = [0,x,1];
S = sigma+2;

for i = 2:sigma+1
        F(i-1) = -k + ((1-2*x(i))*x(i+1)^2+2*x(i)*x(i+1))^-1 *(...
            2*(.5*(x(i+1)^2-x(i-1)^2)-x(i)*(x(i+1)-x(i-1))-b*(.5*(1-2*x(i))*(x(i+1)^2-x(i-1)^2)+x(i)*(x(i+1)-x(i-1))))-...
            k*((1-2*x(i))*x(i-1)^2+2*x(i)*x(i-1)));
end

F(sigma+1) = k*((1-2*x(S))*x(S-1)^2+2*x(S-1)*x(S))+...
            2*(x(S)*(x(S+1)-x(S-1))-.5*(x(S+1)^2-x(S-1)^2)+b*(.5*(1-2*x(S))*(x(S+1)^2-x(S-1)^2)+x(S)*(x(S+1)-x(S-1))))-...
            k*(1-(1-2*x(S))*x(S+1)^2-2*x(S+1)*x(S));
              
for i = S+1:sigma+tau+2
        F(i-1) = -k + (1-(1-2*x(i))*x(i-1)^2-2*x(i)*x(i-1))^-1 *(...
            2*(-.5*(x(i+1)^2-x(i-1)^2)+x(i)*(x(i+1)-x(i-1))+b*(.5*(1-2*x(i))*(x(i+1)^2-x(i-1)^2)+x(i)*(x(i+1)-x(i-1))))-...
            k*(1-(1-2*x(i))*x(i+1)^2-2*x(i)*x(i+1)));
end

end

