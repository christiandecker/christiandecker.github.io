% Replication File for Figure 3 of "The Order of Move in a Conversational War of Attrition"
% Christian Decker, April 2023
% requires "conditions.m"

close all
clear all

%% set Latex interpreter/font
list_factory = fieldnames(get(groot,'factory'));
index_interpreter = find(contains(list_factory,'Interpreter'));
for i = 1:length(index_interpreter)
    default_name = strrep(list_factory{index_interpreter(i)},'factory','default');
    set(groot, default_name,'latex');
end


%% initialize parameters
N = 200; % dimension grid
maxg = .499; % max of grid
Tau = 3; %drop-dead date in natural subgame (Panel A: 2, Panel B: 4, Panel C: 3)
Sigma = 3; %drop-dead date in NiC subgame (Panel A: 2, Panel B: 4, Panel C: 3)


%% grid for kappa and beta
b_vec = linspace(0.001,maxg,N); %bias
k_vec = linspace(0.001,maxg,N); %waiting cost

%% initialize vectors and options
exitflag_vec = NaN(N,N);
fma_vec = NaN(N,N);

tau = Tau-1;
sigma = Sigma-1;
initial = linspace(0.01,maxg-0.01,sigma+tau+1);   
options = optimset('Display','off','MaxFunEvals',1e7,'MaxIter',1e7,'TolFun',1e-12, 'TolX',1e-12);
initial_vec = repmat(initial,[N,1]);
sol_vec = NaN(N,Sigma + Tau - 1); 

%pool = parpool(32);

%% solve for all grid values
tic
for i = 1:N
    disp(i);
    b = b_vec(i);
    ex_aux = NaN(1,N);
    fma_aux = NaN(1,N);    
       
    parfor j=1:N
        k = k_vec(j);
        
        if b + k < 1            
        
            initial = initial_vec(j,:);

            [sol,fval,exitflag] = fsolve(@(x) conditions(x,b,k,tau,sigma),initial,options);

            aux = -sigma-1:1:tau+1;
            sol1 = [0,sol,1];
            bgood = exitflag*(all(diff(sol1)>=0))
            diffx = [diff(sol1),NaN];
            x = [aux;sol1;diffx];


            indiff = @(x)x*(1+b)/(1+2*x*b-b);

            dw = zeros(1,length(sol1)-1);
            dwf = @(x,y,b) 2.*(x-y+b.*(x+y-2.*x.*y));
            
            for l = 1:length(sol1)-1
                dw(l) = integral2(@(x,y)dwf(x,y,b),sol1(l),sol1(l+1),sol1(l),sol1(l+1));
            end
            
            firstmoveradvantage = (2*mod(Sigma,2)-1)*((-1*ones(1,length(sol1)-1)).^(1:length(sol1)-1))*dw';
            
            if bgood>0
                fma_aux(j) = firstmoveradvantage;
            end
            ex_aux(j) = bgood;
            sol_vec(j,:) = sol;
        end
    end
    fma_vec(i,:) = fma_aux;
    exitflag_vec(i,:) = ex_aux;
    initial_vec = sol_vec;
    sol_vec = NaN(N,Sigma + Tau - 1); 
end

toc

maxabs = max(abs(fma_vec),[],"all");

%% Panel A
if Tau==2 & Sigma==2
    fig = figure;
    cMap = interp1([0;0.25;0.49999;0.50001;0.75;1],[1 0 0;1 0 0;1 0.9 0.9; 0.9 1 0.9; 0 1 0; 0 1 0],linspace(0,1,256));
    s = pcolor(k_vec,b_vec,fma_vec);
    s.LineStyle = 'none';
    clim([-maxabs maxabs])
    colormap(cMap)
    colorbar
    text(0.03,0.38,'net last-proposal advantage','FontSize',13)
    text(0.18,0.1,'net first-proposal advantage','FontSize',13)
    xlabel('waiting cost $\kappa$','FontSize',13)
    ylabel('bias $\beta$','FontSize',13)
    title('A: $\sigma=\tau=2$','FontWeight','bold','FontSize',16)
    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    box off
    grid on
    exportgraphics(fig,'fig3A.jpg','Resolution',1000)
end

%% Panel B
if Tau==4 & Sigma==4
    fig = figure;
    cMap = interp1([0;0.25;0.49999;0.50001;0.75;1],[1 0 0;1 0 0;1 0.9 0.9; 0.9 1 0.9; 0 1 0; 0 1 0],linspace(0,1,256));
    s = pcolor(k_vec,b_vec,fma_vec);
    s.LineStyle = 'none';
    clim([-maxabs maxabs])
    colormap(cMap)
    colorbar
    text(0.02,0.42,{'net last-proposal','advantage'},'FontSize',13)
    text(0.15,0.2,'net first-proposal advantage','FontSize',13)
    xlabel('waiting cost $\kappa$','FontSize',13)
    xticks(0:.1:.5)
    ylabel('bias $\beta$','FontSize',13)
    yticks(0:.1:.5)
    axis([0 .5 0 .5])
    title('B: $\sigma=\tau=4$','FontWeight','bold','FontSize',16)
    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    box off
    grid on
    exportgraphics(fig,'fig3B.jpg','Resolution',1000)    
end

%% Panel C
if Tau==3 & Sigma==3
    fig = figure;
    cMap = interp1([0;0.25;0.49999;0.50001;0.75;1],[1 0 0;1 0 0;1 0.9 0.9; 0.9 1 0.9; 0 1 0; 0 1 0],linspace(0,1,256));
    s = pcolor(k_vec,b_vec,fma_vec);
    s.LineStyle = 'none';
    clim([-maxabs maxabs])
    colormap(cMap)
    colorbar
    text(0.1,0.25,'net first-proposal advantage','FontSize',13)
    xlabel('waiting cost $\kappa$','FontSize',13)
    xticks(0:.1:.5)
    ylabel('bias $\beta$','FontSize',13)
    yticks(0:.1:.5)
    axis([0 .5 0 .5])
    title('C: $\sigma=\tau=3$','FontWeight','bold','FontSize',16)
    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    box off
    grid on
    exportgraphics(fig,'fig3C.jpg','Resolution',1000)    
end






