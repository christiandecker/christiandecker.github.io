% Replication File for Table 1 of "The Order of Move in a Conversational War of Attrition"
% Christian Decker, April 2023
% requires "conditions.m"

close all
clear all

%% initialize parameters
b = 0.12; % bias
k = 0.11; % waiting cost

%% initialize vectors and options
tic

drop_vec = 2:16;
N = length(drop_vec);
 
options=optimset('Display','off','MaxFunEvals',1e10,'MaxIter',1e10,'TolFun',1e-8, 'TolX',1e-8);

fma_vec = NaN(N,1);
sec_vec = NaN(N,1);
secla_vec = NaN(N,1);
bgood_vec = NaN(N,1);

%% solve for all grid values
for j=1:N

    Tau = drop_vec(j);
    Sigma = drop_vec(j);
    
    
    tau=  Tau-1;
    sigma = Sigma-1;

    initial = 0.01:0.98/(sigma+tau):0.99;  
    [sol,fval,exitflag] = fsolve(@(x) conditions(x,b,k,tau,sigma),initial,options);

    aux = -sigma-1:1:tau+1;
    sol1 = [0,sol,1];
    bgood = exitflag*(all(diff(sol1)>=0));
    diffx = [diff(sol1),NaN];
    x = [aux;sol1;diffx];


    indiff = @(x)x*(1+b)/(1+2*x*b-b);

    dw = zeros(1,length(sol1)-1);
    dwf = @(x,y,b) 2.*(x-y+b.*(x+y-2.*x.*y));

    for i = 1:length(sol1)-1
        dw(i) = integral2(@(x,y)dwf(x,y,b),sol1(i),sol1(i+1),sol1(i),sol1(i+1));
    end

    firstmoveradvantage = (2*mod(Sigma,2)-1)*((-1*ones(1,length(sol1)-1)).^(1:length(sol1)-1))*dw';

    fma_vec(j) = firstmoveradvantage;
    sec_vec(j) = sol(1);
    secla_vec(j) = sol(end);
    bgood_vec(j) = bgood;
end

bgood_vec

%% Table 1
format long
Table_combined = [drop_vec',sec_vec,secla_vec,fma_vec];
PanelA = Table_combined(1:2:15,:)
PanelB = Table_combined(2:2:14,:)

toc


