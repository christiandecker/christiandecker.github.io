% Replication File for Figure 1 of "The Order of Move in a Conversational War of Attrition"
% Christian Decker, April 2023
% requires "conditions.m"

clear all
close all

%% set Latex interpreter/font
list_factory = fieldnames(get(groot,'factory'));
index_interpreter = find(contains(list_factory,'Interpreter'));
for i = 1:length(index_interpreter)
    default_name = strrep(list_factory{index_interpreter(i)},'factory','default');
    set(groot, default_name,'latex');
end


%% initialize parameters
b = 0.05; %bias
k = 0.1; %waiting cost
Tau = 4; %drop-dead date in natural subgame
Sigma = 4; %drop-dead date in NiC subgame

 
%% solve for quilibrium cutoffs
tic

tau = Tau-1;
sigma = Sigma-1;

initial = 0.01:0.98/(sigma+tau):0.99;   
options = optimset('Display','off','MaxFunEvals',1e10,'MaxIter',1e10,'TolFun',1e-8, 'TolX',1e-8);
[sol,fval,exitflag] = fsolve(@(x) conditions(x,b,k,tau,sigma),initial,options);

aux = -sigma-1:1:tau+1;
sol1 = [0,sol,1];
bgood = exitflag*(all(diff(sol1)>=0))
diffx = [diff(sol1),NaN];
x = [aux;sol1;diffx]


%% Panel A
figA = figure;
plot(sol1,sol1,'ok')
hold on
for i = 1:Tau
    if mod(i,2)==1
        if i==1
            s = fill([sol1(Sigma+i),1,1,sol1(Sigma+i)],[0,0,sol1(Sigma+i+1),sol1(Sigma+i+1)],'b');
            text(sol1(Sigma+i)+(1-sol1(Sigma+i))/2,sol1(Sigma+i+1)/2,num2str(i))
        else
            s = fill([sol1(Sigma+i),1,1,sol1(Sigma+i)],[sol1(Sigma+i-1),sol1(Sigma+i-1),sol1(Sigma+i+1),sol1(Sigma+i+1)],'b');
            text(sol1(Sigma+i)+(1-sol1(Sigma+i))/2,sol1(Sigma+i-1)+(sol1(Sigma+i+1)-sol1(Sigma+i-1))/2,num2str(i))
        end
        
    else
        s = fill([sol1(Sigma+i-1),sol1(Sigma+i+1),sol1(Sigma+i+1),sol1(Sigma+i-1)],[sol1(Sigma+i),sol1(Sigma+i),1,1],'y');
        text(sol1(Sigma+i-1)+(sol1(Sigma+i+1)-sol1(Sigma+i-1))/2,sol1(Sigma+i)+(1-sol1(Sigma+i))/2,num2str(i))
    end
    set(s,'facealpha',.3)
end
for i = 1:Sigma
    if mod(i,2)==1
        if i==1
            s = fill([0,sol1(Sigma+1),sol1(Sigma+1),0],[sol1(Sigma),sol1(Sigma),1,1],'y');
            text(sol1(Sigma+1)/2,sol1(Sigma)+(1-sol1(Sigma))/2,num2str(i))
        else
            s = fill([0,sol1(Sigma+2-i),sol1(Sigma+2-i),0],[sol1(Sigma-i+1),sol1(Sigma-i+1),sol1(Sigma-i+3),sol1(Sigma-i+3)],'y');
            text(sol1(Sigma+2-i)/2,sol1(Sigma-i+1)+(sol1(Sigma-i+3)-sol1(Sigma-i+1))/2,num2str(i))
        end
        
    else
        s = fill([sol1(Sigma-i+1),sol1(Sigma-i+3),sol1(Sigma-i+3),sol1(Sigma-i+1)],[0,0,sol1(Sigma-i+2),sol1(Sigma-i+2)],'b');
        text(sol1(Sigma-i+1)+(sol1(Sigma-i+3)-sol1(Sigma-i+1))/2,sol1(Sigma-i+2)/2,num2str(i))
    end
    set(s,'facealpha',.3)
end
p = plot(sol(sigma+1),sol(sigma+1),'.r');
p.MarkerSize = 30;
fplot(@(x)x,[0,1],'--k')
xlabel('first mover','FontSize',13)
ylabel('second mover','FontSize',13)
box off
grid on
hold off
title('A: Outcomes of the Debate','FontWeight','bold','FontSize',16)
ax = gca;
ax.TitleHorizontalAlignment = 'left';
exportgraphics(figA,'fig1A.jpg','Resolution',1000) 

%% Panel B
figB = figure;
plot(sol1,sol1,'ok')
hold on
for i = 1:length(sol1)-1
    grid = linspace(sol1(i),sol1(i+1),100);
    top = ones(1,100)*sol1(i+1);
    curve = min(1,top);
    bottom = ones(1,100)*sol1(i);
    p = [grid,fliplr(grid)];
    q = [curve,fliplr(top)];
    r = [bottom,fliplr(curve)];
    if mod(sigma,2) == mod(i,2) 
    s = fill(p,q,'b');
    t = fill(p,r,'b');
    else
    s = fill(p,q,'y');
    t = fill(p,r,'y');
    end 
    set(s,'facealpha',.3)
    set(t,'facealpha',.3)
end
p = plot(sol(sigma+1),sol(sigma+1),'.r');
p.MarkerSize = 30;
fplot(@(x)x,[0,1],'--k')
xlabel('first mover','FontSize',13)
ylabel('second mover','FontSize',13)
box off
grid on
hold off
title('B: Switching First Mover $\Rightarrow$ Outcome Flips','FontWeight','bold','FontSize',16)
ax = gca;
ax.TitleHorizontalAlignment = 'left';
exportgraphics(figB,'fig1B.jpg','Resolution',1000) 


toc

