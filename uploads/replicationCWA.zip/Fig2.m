% Replication File for Figure 2 of "The Order of Move in a Conversational War of Attrition"
% Christian Decker, April 2023
% requires "conditions.m"

clear all
close all

%% set Latex interpreter/font
list_factory = fieldnames(get(groot,'factory'));
index_interpreter = find(contains(list_factory,'Interpreter'));
for i = 1:length(index_interpreter)
    default_name = strrep(list_factory{index_interpreter(i)},'factory','default');
    set(groot, default_name,'latex');
end

%% initialize parameters
b = 0.3; %bias
k = 0.4; %waiting cost (Panel A: k=0.4, Panel B: k=0.01)
Tau = 4; %drop-dead date in natural subgame
Sigma = 4; %drop-dead date in NiC subgame

%% solve for quilibrium cutoffs
tic

tau = Tau-1;
sigma = Sigma-1;

initial = 0.01:0.98/(sigma+tau):0.99;   
options = optimset('Display','off','MaxFunEvals',1e10,'MaxIter',1e10,'TolFun',1e-8, 'TolX',1e-8);
[sol,fval,exitflag] = fsolve(@(x) conditions(x,b,k,tau,sigma),initial,options);

aux = -sigma-1:1:tau+1;
sol1 = [0,sol,1];
bgood = exitflag*(all(diff(sol1)>=0))
diffx = [diff(sol1),NaN];
x = [aux;sol1;diffx]

%% define functions
indiff = @(x)x*(1+b)/(1+2*x*b-b);

dw = zeros(1,length(sol1)-1);
dwf = @(x,y,b) 2.*(x-y+b.*(x+y-2.*x.*y));

%% create Figure 2
fig2 = figure('Name','fig')
plot(sol1,sol1,'ok')
hold on
for i = 1:length(sol1)-1
    grid = linspace(sol1(i),sol1(i+1),100);
    top = ones(1,100)*sol1(i+1);
    curve = min(arrayfun(indiff,grid),top);
    bottom = ones(1,100)*sol1(i);
    p = [grid,fliplr(grid)];
    q = [curve,fliplr(top)];
    r = [bottom,fliplr(curve)];
    if mod(sigma,2) == mod(i,2) 
    s = fill(p,q,'r');
    t = fill(p,r,'g');
    else
    s = fill(p,q,'g');
    t = fill(p,r,'r');
    end 
    set(s,'facealpha',.3)
    set(t,'facealpha',.3)
    dw(i) = integral2(@(x,y)dwf(x,y,b),sol1(i),sol1(i+1),sol1(i),sol1(i+1));
end
p = plot(sol(sigma+1),sol(sigma+1),'.r');
p.MarkerSize = 30;
fplot(@(x)x,[0,1],'--k')
fplot(indiff,[0,1],'b')
xlabel('first mover','FontSize',13)
ylabel('second mover','FontSize',13)
box off
grid on
hold off
if b==0.3 & k==0.4 & Tau==4 & Sigma==4
    title('A: First-Proposal Advantage Prevails','FontWeight','bold','FontSize',16)
    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    exportgraphics(fig2,'fig2A.jpg','Resolution',1000)
end
if b==0.3 & k==0.01 & Tau==4 & Sigma==4
    title('B: Last-Proposal Advantage Prevails','FontWeight','bold','FontSize',16)
    ax = gca;
    ax.TitleHorizontalAlignment = 'left';
    exportgraphics(fig2,'fig2B.jpg','Resolution',1000)
end

%% display net first-proposal advantage
firstmoveradvantage = (2*mod(Sigma,2)-1)*((-1*ones(1,length(sol1)-1)).^(1:length(sol1)-1))*dw'

toc


